﻿namespace RegionalDataBases.DTOs.Productos
{
    // Para devolver datos (GET)
    public class ProductoDto
    {
        public int IdProducto { get; set; }
        public string Nombre { get; set; }
        public int IdCategoria { get; set; }
        public string NombreCategoria { get; set; }  // ← Incluimos el nombre de la categoría
        public decimal Precio { get; set; }
        public bool Activo { get; set; }
    }

    // Para crear (POST)
    public class ProductoCreateDto
    {
        public string Nombre { get; set; }
        public int IdCategoria { get; set; }  // ← Solo el ID de la categoría
        public decimal Precio { get; set; }
        public bool Activo { get; set; } = true;
    }

    // Para actualizar (PUT)
    public class ProductoUpdateDto
    {
        public string Nombre { get; set; }
        public int IdCategoria { get; set; }
        public decimal Precio { get; set; }
        public bool Activo { get; set; }
    }

    // DTO adicional: Para listar productos con más detalles
    public class ProductoDetalleDto
    {
        public int IdProducto { get; set; }
        public string Nombre { get; set; }
        public decimal Precio { get; set; }
        public bool Activo { get; set; }

        // Información de la categoría
        public CategoriaSimpleDto Categoria { get; set; }
    }

    // DTO auxiliar para mostrar categoría dentro de producto
    public class CategoriaSimpleDto
    {
        public int IdCategoria { get; set; }
        public string Nombre { get; set; }
    }
}