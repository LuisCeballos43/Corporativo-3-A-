﻿namespace RegionalDataBases.DTOs.Inventario
{
    // Para devolver datos (GET)
    public class InventarioDto
    {
        public int IdInventario { get; set; }
        public int IdSucursal { get; set; }
        public string NombreSucursal { get; set; }
        public int IdProducto { get; set; }
        public string NombreProducto { get; set; }
        public decimal PrecioProducto { get; set; }
        public int Existencia { get; set; }
        public DateTime UltimaActualizacion { get; set; }
    }

    // Para crear (POST)
    public class InventarioCreateDto
    {
        public int IdSucursal { get; set; }
        public int IdProducto { get; set; }
        public int Existencia { get; set; }
    }

    // Para actualizar existencia (PUT)
    public class InventarioUpdateDto
    {
        public int Existencia { get; set; }
    }

    // Para agregar/quitar existencias (PATCH)
    public class InventarioAjusteDto
    {
        public int Cantidad { get; set; }  // Positivo para agregar, negativo para quitar
    }

    // DTO con más detalles
    public class InventarioDetalleDto
    {
        public int IdInventario { get; set; }
        public int Existencia { get; set; }
        public DateTime UltimaActualizacion { get; set; }

        // Información de sucursal
        public SucursalInfoDto Sucursal { get; set; }

        // Información de producto
        public ProductoInfoDto Producto { get; set; }
    }

    // DTOs auxiliares
    public class SucursalInfoDto
    {
        public int IdSucursal { get; set; }
        public string Nombre { get; set; }
        public string Direccion { get; set; }
    }

    public class ProductoInfoDto
    {
        public int IdProducto { get; set; }
        public string Nombre { get; set; }
        public decimal Precio { get; set; }
        public string Categoria { get; set; }
    }
}