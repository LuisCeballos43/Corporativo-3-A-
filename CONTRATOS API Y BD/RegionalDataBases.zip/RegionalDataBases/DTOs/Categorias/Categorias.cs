﻿namespace RegionalDataBases.DTOs.Categorias
{
    // Para devolver datos (GET)
    public class CategoriaDto
    {
        public int IdCategoria { get; set; }
        public string Categoria { get; set; }
        public bool Activo { get; set; }
    }

    // Para crear (POST)
    public class CategoriaCreateDto
    {
        public string Categoria { get; set; }
        public bool Activo { get; set; } = true;
    }

    // Para actualizar (PUT)
    public class CategoriaUpdateDto
    {
        public string Categoria { get; set; }
        public bool Activo { get; set; }
    }
}