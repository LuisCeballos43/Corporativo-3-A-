﻿namespace RegionalDataBases.DTOs.Ventas
{
    // ========== DTOs para Reporte de Venta (Maestro) ==========

    // Para listar ventas (GET)
    public class VentaDto
    {
        public int IdReporte { get; set; }
        public int IdSucursal { get; set; }
        public string NombreSucursal { get; set; }
        public int IdCliente { get; set; }
        public string NombreCliente { get; set; }
        public decimal TotalVentas { get; set; }
        public DateTime FechaRecepcion { get; set; }
        public int CantidadProductos { get; set; }  // Cuántos productos diferentes
    }

    // Para ver detalle completo de una venta (GET por ID)
    public class VentaDetalleDto
    {
        public int IdReporte { get; set; }
        public decimal TotalVentas { get; set; }
        public DateTime FechaRecepcion { get; set; }

        // Información de sucursal
        public SucursalVentaDto Sucursal { get; set; }

        // Información de cliente
        public ClienteVentaDto Cliente { get; set; }

        // Lista de productos vendidos
        public List<DetalleVentaDto> Detalles { get; set; }
    }

    // Para crear una venta completa (POST)
    public class VentaCreateDto
    {
        public int IdSucursal { get; set; }
        public int IdCliente { get; set; }

        // Lista de productos a vender
        public List<DetalleVentaCreateDto> Detalles { get; set; }
    }

    // ========== DTOs para Detalle de Ventas ==========

    // Para mostrar un producto vendido
    public class DetalleVentaDto
    {
        public int IdDetalle { get; set; }
        public int IdProducto { get; set; }
        public string NombreProducto { get; set; }
        public int Cantidad { get; set; }
        public decimal PrecioUnitario { get; set; }
        public decimal PrecioVenta { get; set; }  // Cantidad * PrecioUnitario
    }

    // Para agregar un producto a la venta (al crearla)
    public class DetalleVentaCreateDto
    {
        public int IdProducto { get; set; }
        public int Cantidad { get; set; }
        // El precio se toma automáticamente del producto
    }

    // ========== DTOs auxiliares ==========

    public class SucursalVentaDto
    {
        public int IdSucursal { get; set; }
        public string Nombre { get; set; }
        public string Direccion { get; set; }
        public string Telefono { get; set; }
    }

    public class ClienteVentaDto
    {
        public int IdCliente { get; set; }
        public string Nombre { get; set; }
        public string Email { get; set; }
        public string Telefono { get; set; }
    }

    // Para reportes y estadísticas
    public class VentasPorFechaDto
    {
        public DateTime Fecha { get; set; }
        public decimal TotalVentas { get; set; }
        public int CantidadVentas { get; set; }
    }

    public class VentasPorSucursalDto
    {
        public int IdSucursal { get; set; }
        public string NombreSucursal { get; set; }
        public decimal TotalVentas { get; set; }
        public int CantidadVentas { get; set; }
    }

    public class ProductoMasVendidoDto
    {
        public int IdProducto { get; set; }
        public string NombreProducto { get; set; }
        public int CantidadVendida { get; set; }
        public decimal TotalGenerado { get; set; }
    }
}