﻿namespace RegionalDataBases.DTOs.Sucursales
{
    // Para devolver datos (GET)
    public class SucursalDto
    {
        public int IdSucursal { get; set; }
        public string Nombre { get; set; }
        public string Direccion { get; set; }
        public string Telefono { get; set; }
        public bool Activa { get; set; }
    }

    // Para crear (POST)
    public class SucursalCreateDto
    {
        public string Nombre { get; set; }
        public string Direccion { get; set; }
        public string Telefono { get; set; }
        public bool Activa { get; set; } = true;
    }

    // Para actualizar (PUT)
    public class SucursalUpdateDto
    {
        public string Nombre { get; set; }
        public string Direccion { get; set; }
        public string Telefono { get; set; }
        public bool Activa { get; set; }
    }
}