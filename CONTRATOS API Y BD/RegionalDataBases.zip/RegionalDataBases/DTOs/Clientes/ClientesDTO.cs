﻿namespace RegionalDataBases.DTOs.Clientes
{
    // Para devolver datos (GET)
    public class ClienteDto
    {
        public int IdCliente { get; set; }
        public string Nombre { get; set; }
        public string Telefono { get; set; }
        public string Direccion { get; set; }
        public string Email { get; set; }
        public int IdSucursal { get; set; }
        public string NombreSucursal { get; set; }  // ← Nombre de la sucursal
        public bool Activo { get; set; }
    }

    // Para crear (POST)
    public class ClienteCreateDto
    {
        public string Nombre { get; set; }
        public string Telefono { get; set; }
        public string Direccion { get; set; }
        public string Email { get; set; }
        public int IdSucursal { get; set; }
        public bool Activo { get; set; } = true;
    }

    // Para actualizar (PUT)
    public class ClienteUpdateDto
    {
        public string Nombre { get; set; }
        public string Telefono { get; set; }
        public string Direccion { get; set; }
        public string Email { get; set; }
        public int IdSucursal { get; set; }
        public bool Activo { get; set; }
    }

    // DTO con más detalles (incluye objeto sucursal completo)
    public class ClienteDetalleDto
    {
        public int IdCliente { get; set; }
        public string Nombre { get; set; }
        public string Telefono { get; set; }
        public string Direccion { get; set; }
        public string Email { get; set; }
        public bool Activo { get; set; }

        // Información completa de la sucursal
        public SucursalSimpleDto Sucursal { get; set; }
    }

    // DTO auxiliar para sucursal dentro de cliente
    public class SucursalSimpleDto
    {
        public int IdSucursal { get; set; }
        public string Nombre { get; set; }
        public string Telefono { get; set; }
    }
}